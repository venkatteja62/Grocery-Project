import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './model/User';
import { environment } from '../environments/environment';
import { Cart } from './model/Cart';
import { Order } from './model/Order';


const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class CartService {
  carts: Cart[]
  orders: Order[]

  constructor(public http: HttpClient) {

  }

  addToCart(cart: Cart) {
    return this.http.post('http://172.18.218.134:' + environment.port + '/grocery/cart/save', cart, httpOptions)
  }

  getCartByUid(uid: number) {
    return this.http.get('http://172.18.218.134:' + environment.port + '/grocery/cart/all/' + uid, httpOptions)
  }

  deleteCartItem(cartid: number) {
    return this.http.delete('http://172.18.218.134:' + environment.port + '/grocery/cart/delete/' + cartid, httpOptions)
  }

  placeOrder(order: Order) {

    // this.carts.forEach(cart => {
    //   cart.status = true
    //   cart.ofk = 0

    //   console.log(cart)
    // })
    this.http.post('http://172.18.218.134:' + environment.port + '/grocery/order/add', order, httpOptions)
      .subscribe((res: Order) => {
        if (res !== null) {


    this.carts.forEach(cart => {
      cart.status = true
      cart.ofk = res.oid
      console.log(cart)
    this.http.put('http://172.18.218.134:' + environment.port + '/grocery/cart/edit', cart, httpOptions)
      .subscribe(res => {
        console.log(res)
      })
        })
      }
    }, err => {
      console.log(err)
    })

  }

  getMyOrder(uid: number) {
    return this.http.get('http://172.18.218.134:' + environment.port + '/grocery/order/all/' + uid, httpOptions)
  }

}
