import { Product } from './../model/Product';
import { Category} from './../model/Category';
import { Status} from './../model/Status';

import { Component, OnInit, Input } from '@angular/core';

import { Router, Event, NavigationEnd } from '@angular/router';
import { ProductService } from './../product.service';
import { CategoryService } from '../category.service';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})

export class ProductComponent implements OnInit {

  product: Product
  category:Category
  categorys:Category[]
  successFlag: boolean
  errorFlag: boolean
  products: Product[]
  progressFlag: boolean
  
 
  public constructor(public prodService: ProductService, public router: Router,public catService:CategoryService) {
    this.initProduct()
    this.products = []
    this.product = new Product()
    this.category=new Category()
  
   
    
    this.catService.getCategory()
    .subscribe((res: Category[]) => {
      if (res) {
        this.categorys = res
      }

      this.progressFlag = false

    })

  }

  ngOnInit() {
  }

  productSubmit(productForm) {
    this.successFlag = false
    this.errorFlag = false

    this.prodService.addProduct(this.product)
      .subscribe((res: Product) => {

        if (res !== null) {
          this.successFlag = true
          this.product = new Product()
          productForm.form.markAsPristine()
          this.router.navigateByUrl('/product')
        }
        else {
          this.errorFlag = true

        }
      }, err => {
        console.log(err)
        this.errorFlag = true

      })

  }

  getProduct() {
    this.progressFlag = true
    this.prodService.getProduct()
      .subscribe((res: Product[]) => {
        console.log(res)
        if (res) {
          this.products = res
          
        }

        this.progressFlag = false

      })
  }
  

  initProduct() {
    
    this.product = {
      cid: 0,
      pname: '',
      pid:0,
      pqty:0,
      unit:'',
      imageUrl:'',
      uqty:0,
      price:0,
      cfk:0
      
    }

  }
  deleteProduct(pid, index) {
    this.prodService.deleteProduct(pid)
      .subscribe((res: Status) => {
        if (res.queryStatus)
          this.categorys.splice(index, 1)
      })
  
  }
  
}
