
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'
import { RouterModule, Routes } from '@angular/router'
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { CategoryComponent } from './category/category.component';
import { ProductComponent } from './product/product.component';
import { EditComponent } from './edit/edit.component';
import { SearchComponent } from './search/search.component';
import { ViewproductComponent } from './viewproduct/viewproduct.component';
import { CartComponent } from './cart/cart.component';
import { OrderComponent } from './order/order.component';


const routes: Routes = [
  
  {
    path: "signin",
    component: SignInComponent
  },
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "admin",
    component: AdminComponent
  },
  {
    path: "signup",
    component: SignUpComponent
  },
  {
    path: "category",
    component: CategoryComponent
  },
  {
    path: "product",
    component: ProductComponent
  },
  {
    path: "search",
    component: SearchComponent
  },
  {
    path: "Viewproduct",
    component: ViewproductComponent
  }
  ,
  {
    path: "cart",
    component: CartComponent
  },
  {
    path: "order",
    component: OrderComponent
  }
  
  
  
]

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SignUpComponent,
    SignInComponent,
    HomeComponent,
    AdminComponent,
    CategoryComponent,
    ProductComponent,
    EditComponent,
    SearchComponent,
    ViewproductComponent,
    CartComponent,
    OrderComponent,
   

    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }