
export class Category {
    cid: number
    categoryName: string
    constructor() {
        this.cid = 0
        this.categoryName = ''
        
    }
}
